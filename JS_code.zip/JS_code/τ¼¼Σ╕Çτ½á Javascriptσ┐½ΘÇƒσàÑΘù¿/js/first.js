(function(){
	var name = 'mjj';
	var hello = function (){
		alert('hello ' + name);
	}
	window.first = hello;
})();