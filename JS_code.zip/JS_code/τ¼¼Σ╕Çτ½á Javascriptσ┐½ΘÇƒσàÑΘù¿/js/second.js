(function(){
	var name = 'jack';
	var hello = function(){
		alert('hello ' + name);
	}
	window.second = hello;
})();